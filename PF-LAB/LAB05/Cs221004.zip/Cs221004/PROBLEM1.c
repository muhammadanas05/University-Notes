#include <stdio.h>
int main(){
	int m;
	printf("Enter a marks : ");
	scanf("%d",&m);
	switch (m)
	{
		case 86:
			printf("For your entered marks, your grade is A and your GPA is 4.00.");
			break;
		case 82:
			printf("For your entered marks, your grade is A- and your GPA is 3.67.");
			break;
		case 78:
			printf("For your entered marks, your grade is B+ and your GPA is 3.33.");
			break;
		case 74:
			printf("For your entered marks, your grade is B and your GPA is 3.00.");
			break;
		case 70:
			printf("For your entered marks, your grade is B- and your GPA is 2.67.");
			break;
		case 66:
			printf("For your entered marks, your grade is C+ and your GPA is 2.33.");
			break;
		case 62:
			printf("For your entered marks, your grade is C and your GPA is 2.00.");
			break;
		case 58:
			printf("For your entered marks, your grade is C- and your GPA is 1.67.");
			break;		
		case 54:
			printf("For your entered marks, your grade is D+ and your GPA is 1.33.");
			break;
		case 50:
			printf("For your entered marks, your grade is D and your GPA is 1.00.");
			break;	
		default :
		    printf("FAIL");							
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
}
