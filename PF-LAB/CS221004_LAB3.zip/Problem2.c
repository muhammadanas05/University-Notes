#include <stdio.h>
int main()
{
    float d, v, a, t;

    printf("Input distance (m): ");
    scanf("%f", &d);
    printf("Input velocity (m/s): ");
    scanf("%f", &v);

    t = d/v;
    a = v/t;

    printf("Acc is %f and Time is %f", a, t);
  
  return 0;
}
