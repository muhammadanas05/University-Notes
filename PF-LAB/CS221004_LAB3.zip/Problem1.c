#include<stdio.h>
int main()
{
	float km,m,feet;
	printf("Enter the distance between two cities\n");
	scanf("%f",&km);
	m= km*1000;
	feet=km*3280.84;
	printf("Distance in KM : %f\n", km);
	printf("\nDistance in meters = %f km",m);
	printf("\nDistance in feets = %f feet",feet);
	return 0;
	
}
