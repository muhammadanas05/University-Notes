#include <stdio.h>
int main()
{
int RN,lsd,msd,SUM;
 
 printf("ENTER YOUR ROLLNUMBER :");
 scanf("%d", &RN);
 
 lsd= RN%10;
 msd= RN/100000 ;	
 SUM= lsd +msd;
 printf("The SUM of LSD = %d ", lsd);
 printf("The SUM of MSD = %d ", msd);
 printf("The SUM of LSD and MSD = %d ", SUM);
 
	
}
