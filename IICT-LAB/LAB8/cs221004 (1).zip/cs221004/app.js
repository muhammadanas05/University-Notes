function checkpass() 
{
  var pass = document.getElementById("pass").value;
  var retypePass = document.getElementById("repass").value;
  if (pass === retypePass) 
  {
    var dob = prompt("Please enter your Date of Birth:");
    document.getElementById("formoutput").innerHTML = "Username: "
     + document.getElementById("username").value + "<br>" + 
     "Password: " + pass+ "<br>" + "DOB: " + dob;
  } 
  else 
  {
    alert("Passwords do not match!");
  }
}





